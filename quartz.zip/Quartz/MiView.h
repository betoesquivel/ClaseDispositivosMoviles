//
//  MiView.h
//  Quartz
//
//  Created by José Alberto Esquivel on 3/12/15.
//  Copyright (c) 2015 José Alberto Esquivel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MiView : UIView

@property BOOL triangleActivated;
@property BOOL rectangleActivated;
@property BOOL circleActivated;

@end

//
//  AppDelegate.h
//  MasterMine
//
//  Created by beto on 1/29/15.
//  Copyright (c) 2015 beto. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


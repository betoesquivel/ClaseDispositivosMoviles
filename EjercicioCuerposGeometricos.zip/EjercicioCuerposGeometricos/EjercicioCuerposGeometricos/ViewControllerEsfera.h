//
//  ViewControllerEsfera.h
//  EjercicioCuerposGeometricos
//
//  Created by alumno on 2/5/15.
//  Copyright (c) 2015 ITESM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewControllerEsfera : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *oImagen;
@property (weak, nonatomic) IBOutlet UITextField *oRadio;
@property (weak, nonatomic) IBOutlet UIButton *obGuardar;

@end

//
//  AppDelegate.h
//  divisasIOS
//
//  Created by alumno on 15/01/15.
//  Copyright (c) 2015 Roberto Ruiz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

